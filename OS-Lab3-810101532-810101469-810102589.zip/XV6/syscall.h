// System call numbers
#define SYS_fork    1
#define SYS_exit    2
#define SYS_wait    3
#define SYS_pipe    4
#define SYS_read    5
#define SYS_kill    6
#define SYS_exec    7
#define SYS_fstat   8
#define SYS_chdir   9
#define SYS_dup    10
#define SYS_getpid 11
#define SYS_sbrk   12
#define SYS_sleep  13
#define SYS_uptime 14
#define SYS_open   15
#define SYS_write  16
#define SYS_mknod  17
#define SYS_unlink 18
#define SYS_link   19
#define SYS_mkdir  20
#define SYS_close  21
#define SYS_simple_arithmetic_syscall 22
#define SYS_make_duplicate 23
#define SYS_show_process_family 24
#define SYS_grep_syscall 25
#define SYS_set_priority_syscall 26

// Debug systemcalls for scheduler and cpu queue
#define SYS_print_process_info 27

// == Throughput measurement syscalls ==
#define SYS_start_measuring 28
#define SYS_stop_measuring 29
// =====================================
