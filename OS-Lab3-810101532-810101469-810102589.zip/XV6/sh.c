// Shell.

#include "types.h"
#include "user.h"
#include "fcntl.h"
#include "stat.h"
#include "fs.h"



// Parsed command representation
#define EXEC  1
#define REDIR 2
#define PIPE  3
#define LIST  4
#define BACK  5
#define TAB 7
#define MAXARGS 10

// Program listing
#define MAX_FILES 128
#define MAX_NAME (DIRSIZ + 1)
int get_user_programs(char names[MAX_FILES][MAX_NAME]);
void print_string_array(char arr[MAX_FILES][MAX_NAME], int count);
int find_matches(char *prefix, char names[MAX_FILES][MAX_NAME],char matches[MAX_FILES][MAX_NAME], int count);
void console_write(char *str);

struct cmd {
  int type;
};

struct execcmd {
  int type;
  char *argv[MAXARGS];
  char *eargv[MAXARGS];
};

struct redircmd {
  int type;
  struct cmd *cmd;
  char *file;
  char *efile;
  int mode;
  int fd;
};

struct pipecmd {
  int type;
  struct cmd *left;
  struct cmd *right;
};

struct listcmd {
  int type;
  struct cmd *left;
  struct cmd *right;
};

struct backcmd {
  int type;
  struct cmd *cmd;
};


struct tab
{
  int type;
  char *cmd; 
  int tab_check;
};



int fork1(void);  // Fork but panics on failure.
void panic(char*);
struct cmd *parsecmd(char*);

// Execute cmd.  Never returns.
void
runcmd(struct cmd *cmd)
{
  int p[2];
  struct backcmd *bcmd;
  struct execcmd *ecmd;
  struct listcmd *lcmd;
  struct pipecmd *pcmd;
  struct redircmd *rcmd;

  // struct exclamation *excmd; //we don't need this

  if(cmd == 0)
    exit();

  switch(cmd->type){
  default:
    panic("runcmd");
    
  case TAB: {
    struct tab *tcmd = (struct tab*)cmd;

    char (*programs)[MAX_NAME] = malloc(sizeof(char) * MAX_FILES * MAX_NAME);
    char (*matches)[MAX_NAME]  = malloc(sizeof(char) * MAX_FILES * MAX_NAME);

    if (!programs || !matches) {
      printf(2, "malloc failed\n");
      exit();
    }

    int n = get_user_programs(programs);
    int m = find_matches(tcmd->cmd, programs, matches, n);

    if(m == 1)
      console_write(matches[0] );
    
    else if(m > 1 && tcmd->tab_check){
      print_string_array(matches, m);
      printf(1 , "$ ");
      console_write(tcmd->cmd);
    }
    else
      console_write(tcmd->cmd);
    

    free(programs);
    free(matches);
    break;
  }
  
  case EXEC:
    ecmd = (struct execcmd*)cmd;
    if(ecmd->argv[0] == 0)
      exit();
    exec(ecmd->argv[0], ecmd->argv);
    printf(2, "exec %s failed\n", ecmd->argv[0]);
    break;

  case REDIR:
    rcmd = (struct redircmd*)cmd;
    close(rcmd->fd);
    if(open(rcmd->file, rcmd->mode) < 0){
      printf(2, "open %s failed\n", rcmd->file);
      exit();
    }
    runcmd(rcmd->cmd);
    break;

  case LIST:
    lcmd = (struct listcmd*)cmd;
    if(fork1() == 0)
      runcmd(lcmd->left);
    wait();
    runcmd(lcmd->right);
    break;

  case PIPE:
    pcmd = (struct pipecmd*)cmd;
    if(pipe(p) < 0)
      panic("pipe");
    if(fork1() == 0){
      close(1);
      dup(p[1]);
      close(p[0]);
      close(p[1]);
      runcmd(pcmd->left);
    }
    if(fork1() == 0){
      close(0);
      dup(p[0]);
      close(p[0]);
      close(p[1]);
      runcmd(pcmd->right);
    }
    close(p[0]);
    close(p[1]);
    wait();
    wait();
    break;

  case BACK:
    bcmd = (struct backcmd*)cmd;
    if(fork1() == 0)
      runcmd(bcmd->cmd);
    break;
  }
  exit();
}

int contains_tab(char *output) {
  for (int i = 0; output[i] != '\0'; i++) {
    if (output[i] == '\t') {
      return 1;  
    }
  }
  return 0;
}

int
getcmd(char *output, int noutput)
{
  if(!contains_tab(output))
    printf(2, "$ ");
    
  memset(output, 0, noutput);
  gets(output, noutput);

  if(output[0] == 0) // EOF
    return -1;
  return 0;
}

int
main(void)
{
  static char output[100];
  int fd;

  // Ensure that three file descriptors are open.
  while((fd = open("console", O_RDWR)) >= 0){
    if(fd >= 3){
      close(fd);
      break;
    }
  }

  // Read and run input commands.
  while(getcmd(output, sizeof(output)) >= 0){
    if(output[0] == 'c' && output[1] == 'd' && output[2] == ' '){
      // Chdir must be called by the parent, not the child.
      output[strlen(output)-1] = 0;  // chop \n
      if(chdir(output+3) < 0)
        printf(2, "cannot cd %s\n", output+3);
      continue;
    }
    if(fork1() == 0)
      runcmd(parsecmd(output));
    wait();
  }
  exit();
}

void
panic(char *s)
{
  printf(2, "%s\n", s);
  exit();
}

int
fork1(void)
{
  int pid;

  pid = fork();
  if(pid == -1)
    panic("fork");
  return pid;
}

//PAGEBREAK!
// Constructors

struct cmd*
execcmd(void)
{
  struct execcmd *cmd;

  cmd = malloc(sizeof(*cmd));
  memset(cmd, 0, sizeof(*cmd));
  cmd->type = EXEC;
  return (struct cmd*)cmd;
}

struct cmd*
redircmd(struct cmd *subcmd, char *file, char *efile, int mode, int fd)
{
  struct redircmd *cmd;

  cmd = malloc(sizeof(*cmd));
  memset(cmd, 0, sizeof(*cmd));
  cmd->type = REDIR;
  cmd->cmd = subcmd;
  cmd->file = file;
  cmd->efile = efile;
  cmd->mode = mode;
  cmd->fd = fd;
  return (struct cmd*)cmd;
}

struct cmd*
pipecmd(struct cmd *left, struct cmd *right)
{
  struct pipecmd *cmd;

  cmd = malloc(sizeof(*cmd));
  memset(cmd, 0, sizeof(*cmd));
  cmd->type = PIPE;
  cmd->left = left;
  cmd->right = right;
  return (struct cmd*)cmd;
}

struct cmd*
listcmd(struct cmd *left, struct cmd *right)
{
  struct listcmd *cmd;

  cmd = malloc(sizeof(*cmd));
  memset(cmd, 0, sizeof(*cmd));
  cmd->type = LIST;
  cmd->left = left;
  cmd->right = right;
  return (struct cmd*)cmd;
}

struct cmd*
backcmd(struct cmd *subcmd)
{
  struct backcmd *cmd;

  cmd = malloc(sizeof(*cmd));
  memset(cmd, 0, sizeof(*cmd));
  cmd->type = BACK;
  cmd->cmd = subcmd;
  return (struct cmd*)cmd;
}
//PAGEBREAK!
// Parsing

char whitespace[] = " \t\r\n\v";
char symbols[] = "<|>&;()";

int
gettoken(char **ps, char *es, char **q, char **eq)
{
  char *s;
  int ret;

  s = *ps;
  while(s < es && strchr(whitespace, *s))
    s++;
  if(q)
    *q = s;
  ret = *s;
  switch(*s){
  case 0:
    break;
  case '|':
  case '(':
  case ')':
  case ';':
  case '&':
  case '<':
    s++;
    break;
  case '>':
    s++;
    if(*s == '>'){
      ret = '+';
      s++;
    }
    break;
  default:
    ret = 'a';
    while(s < es && !strchr(whitespace, *s) && !strchr(symbols, *s))
      s++;
    break;
  }
  if(eq)
    *eq = s;

  while(s < es && strchr(whitespace, *s))
    s++;
  *ps = s;
  return ret;
}

int
peek(char **ps, char *es, char *toks)
{
  char *s;

  s = *ps;
  while(s < es && strchr(whitespace, *s))
    s++;
  *ps = s;
  return *s && strchr(toks, *s);
}

struct cmd *parseline(char**, char*);
struct cmd *parsepipe(char**, char*);
struct cmd *parseexec(char**, char*);
struct cmd *nulterminate(struct cmd*);

struct cmd*
parsecmd(char *s)
{
  char *es;
  struct cmd *cmd;
  
  int len = strlen(s);
  
  if (len > 2 && s[len - 2] == '\t') {
    struct tab *tcmd = malloc(sizeof(*tcmd));
    memset(tcmd, 0, sizeof(*tcmd));
    tcmd->type = TAB;
    tcmd->tab_check = (s[len - 3] == 'T') ? 1 : 0; // if there was a T before tab
    s[len - 3] = '\0';
    tcmd->cmd = s;
    return (struct cmd*)tcmd;
  }

  es = s + strlen(s);
  cmd = parseline(&s, es);
  peek(&s, es, "");
  if(s != es){
    printf(2, "leftovers: %s\n", s);
    panic("syntax");
  }
  nulterminate(cmd);
  return cmd;
}

struct cmd*
parseline(char **ps, char *es)
{
  struct cmd *cmd;

  cmd = parsepipe(ps, es);
  while(peek(ps, es, "&")){
    gettoken(ps, es, 0, 0);
    cmd = backcmd(cmd);
  }
  if(peek(ps, es, ";")){
    gettoken(ps, es, 0, 0);
    cmd = listcmd(cmd, parseline(ps, es));
  }
  return cmd;
}

struct cmd*
parsepipe(char **ps, char *es)
{
  struct cmd *cmd;

  cmd = parseexec(ps, es);
  if(peek(ps, es, "|")){
    gettoken(ps, es, 0, 0);
    cmd = pipecmd(cmd, parsepipe(ps, es));
  }
  return cmd;
}

struct cmd*
parseredirs(struct cmd *cmd, char **ps, char *es)
{
  int tok;
  char *q, *eq;

  while(peek(ps, es, "<>")){
    tok = gettoken(ps, es, 0, 0);
    if(gettoken(ps, es, &q, &eq) != 'a')
      panic("missing file for redirection");
    switch(tok){
    case '<':
      cmd = redircmd(cmd, q, eq, O_RDONLY, 0);
      break;
    case '>':
      cmd = redircmd(cmd, q, eq, O_WRONLY|O_CREATE, 1);
      break;
    case '+':  // >>
      cmd = redircmd(cmd, q, eq, O_WRONLY|O_CREATE, 1);
      break;
    }
  }
  return cmd;
}

struct cmd*
parseblock(char **ps, char *es)
{
  struct cmd *cmd;

  if(!peek(ps, es, "("))
    panic("parseblock");
  gettoken(ps, es, 0, 0);
  cmd = parseline(ps, es);
  if(!peek(ps, es, ")"))
    panic("syntax - missing )");
  gettoken(ps, es, 0, 0);
  cmd = parseredirs(cmd, ps, es);
  return cmd;
}

struct cmd*
parseexec(char **ps, char *es)
{
  char *q, *eq;
  int tok, argc;
  struct execcmd *cmd;
  struct cmd *ret;

  if(peek(ps, es, "("))
    return parseblock(ps, es);

  ret = execcmd();
  cmd = (struct execcmd*)ret;

  argc = 0;
  ret = parseredirs(ret, ps, es);
  while(!peek(ps, es, "|)&;")){
    if((tok=gettoken(ps, es, &q, &eq)) == 0)
      break;
    if(tok != 'a')
      panic("syntax");
    cmd->argv[argc] = q;
    cmd->eargv[argc] = eq;
    argc++;
    if(argc >= MAXARGS)
      panic("too many args");
    ret = parseredirs(ret, ps, es);
  }
  cmd->argv[argc] = 0;
  cmd->eargv[argc] = 0;
  return ret;
}

// NUL-terminate all the counted strings.
struct cmd*
nulterminate(struct cmd *cmd)
{
  int i;
  struct backcmd *bcmd;
  struct execcmd *ecmd;
  struct listcmd *lcmd;
  struct pipecmd *pcmd;
  struct redircmd *rcmd;

  if(cmd == 0)
    return 0;

  switch(cmd->type){
  case EXEC:
    ecmd = (struct execcmd*)cmd;
    for(i=0; ecmd->argv[i]; i++)
      *ecmd->eargv[i] = 0;
    break;

  case REDIR:
    rcmd = (struct redircmd*)cmd;
    nulterminate(rcmd->cmd);
    *rcmd->efile = 0;
    break;

  case PIPE:
    pcmd = (struct pipecmd*)cmd;
    nulterminate(pcmd->left);
    nulterminate(pcmd->right);
    break;

  case LIST:
    lcmd = (struct listcmd*)cmd;
    nulterminate(lcmd->left);
    nulterminate(lcmd->right);
    break;

  case BACK:
    bcmd = (struct backcmd*)cmd;
    nulterminate(bcmd->cmd);
    break;
  }
  return cmd;
}

char*
safestrcpy(char *s, const char *t, int n)
{
  char *os;

  os = s;
  if(n <= 0)
    return os;
  while(--n > 0 && (*s++ = *t++) != 0)
    ;
  *s = 0;
  return os;
}

int
strncmp(const char *p, const char *q, uint n)
{
  while(n > 0 && *p && *p == *q)
    n--, p++, q++;
  if(n == 0)
    return 0;
  return (uchar)*p - (uchar)*q;
}


int get_user_programs(char names[MAX_FILES][MAX_NAME]) {
  char buf[512], *p;
  int fd;
  struct dirent de;
  struct stat st;
  int count = 0;

  if((fd = open(".", 0)) < 0){
    printf(2, "list_programs: cannot open .\n");
    return -1;
  }

  if(fstat(fd, &st) < 0){
    printf(2, "list_programs: cannot stat .\n");
    close(fd);
    return -1;
  }

  if(st.type != T_DIR){
    printf(2, "list_programs: not a directory\n");
    close(fd);
    return -1;
  }

  while(read(fd, &de, sizeof(de)) == sizeof(de)){
    if(de.inum == 0)
      continue;
    if(count >= MAX_FILES)
      break;

    strcpy(buf, "./");
    p = buf + strlen(buf);
    memmove(p, de.name, DIRSIZ);
    p[DIRSIZ - 1] = 0;

    if(stat(buf, &st) < 0)
      continue;

    if(st.type == T_FILE){
      if(strncmp(de.name, "README", 6) == 0)
        continue;

      memmove(names[count], de.name, DIRSIZ - 1);
      names[count][DIRSIZ - 1] = 0;
      count++;
    }
  }

  close(fd);

  safestrcpy(names[count++], "cd",      MAX_NAME);
  // safestrcpy(names[count++], "exit",    MAX_NAME);
  // safestrcpy(names[count++], "help",    MAX_NAME);
  // safestrcpy(names[count++], "history", MAX_NAME);

  return count;
}


int
find_matches(char *prefix, char names[MAX_FILES][MAX_NAME],
             char matches[MAX_FILES][MAX_NAME], int count)
{
  int prefix_len = strlen(prefix);
  if(prefix_len == 0)
    return 0;
  int mcount = 0;

  for (int i = 0; i < count; i++) {
    if (strncmp(prefix, names[i], prefix_len) == 0) {
      if (mcount < MAX_FILES) {
        safestrcpy(matches[mcount], names[i], MAX_NAME);
        mcount++;
      }
    }
  }

  return mcount;
}

void
print_string_array(char arr[MAX_FILES][MAX_NAME], int count)
{
  printf(1, "\n-----------------\n");
  for (int i = 0; i < count; i++) {
    if (arr[i][0] == 0)
      continue; // skip empty strings
    printf(1, "  %s\n", arr[i]);
  }
  printf(1, "-----------------\n");
}

void*
memcpy(void *dst, const void *src, uint n)
{
  return memmove(dst, src, n);
}

void
console_write(char *str)
{
  char tab_buf[128];
  tab_buf[0] = '\x01';
  memcpy(tab_buf + 1, str, strlen(str));
  write(1, tab_buf, strlen(str) + 1);
}
